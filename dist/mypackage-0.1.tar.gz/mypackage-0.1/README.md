# Mypackage
Created as part of EDSA course to publish your own Python Package. 

